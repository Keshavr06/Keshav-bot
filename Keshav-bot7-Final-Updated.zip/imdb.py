import requests

OMDB_API_KEY = "YOUR_OMDB_API_KEY"

def get_imdb_details(movie_name):
    url = f"http://www.omdbapi.com/?t={movie_name}&apikey={OMDB_API_KEY}&plot=full"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        if data.get("Response") == "True":
            result = f"**मूवी का नाम:** {data.get('Title', 'N/A')}\n"
            result += f"**रिलीज़ वर्ष:** {data.get('Year', 'N/A')}\n"
            result += f"**रेटिंग:** {data.get('imdbRating', 'N/A')}\n"
            result += f"**शैली:** {data.get('Genre', 'N/A')}\n"
            result += f"**डायरेक्टर:** {data.get('Director', 'N/A')}\n"
            result += f"**कहानी:** {data.get('Plot', 'N/A')}\n"
            result += f"**पोस्टर:** {data.get('Poster', '')}"
            return result
        else:
            return "मूवी नहीं मिली। कृपया सही नाम दर्ज करें।"
    else:
        return "IMDB API से डेटा प्राप्त करने में त्रुटि हुई।"
